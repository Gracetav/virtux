<!DOCTYPE html>
<html>
<head>
    @include('admin.css')
</head>
<body>  
    @include('admin.header')

    @include('admin.sidebar')
    <!--sidebar Navigation -->
    <div class="page-content"> 
    <div class="page-header">
        <div class="container-fluid">

        <form action="">
        <div>
            <input type="text" name="category">
        </div>
        <div>
            <input type="submit" class="btn" value="Add Category" >
        </div>
       </form>


        </div>
    </div>
    </div>
</body>
</html>